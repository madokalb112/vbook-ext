load('config.js');

function execute(key, page) {
    let target = BASE_URL + '/browse?keyword=' + encodeURIComponent(key || '') + '&sort=relevance:desc';
    if (page && page !== '1') {
        target = target + '&page=' + page;
    }
    let browser = null;
    try {
        if (typeof Engine === 'undefined' || !Engine || !Engine.newBrowser) {
            return Response.error('Engine.newBrowser khong kha dung');
        }
        browser = Engine.newBrowser();
        if (!launchBrowser(browser, target)) {
            return Response.error('Khong the khoi chay trinh duyet');
        }
        let doc = waitForSelector(browser, 'a[href*="/title/"], .browse__results, .title-row-card, .title-detail__notfound', 25);
        if (!doc) return Response.success([], '');

        let data = extractCards(doc);
        let next = '';
        if (data.length >= 30 || doc.select('.npager button[aria-label="Next page"]:not([disabled])').size() > 0) {
            next = '' + (pageNum(page) + 1);
        }
        return Response.success(data, next);
    } catch (e) {
        return Response.error('Loi: ' + e);
    } finally {
        if (browser) {
            try { browser.close(); } catch (e) {}
        }
    }
}
