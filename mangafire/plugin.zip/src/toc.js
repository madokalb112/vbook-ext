load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let browser = null;
    try {
        if (typeof Engine === 'undefined' || !Engine || !Engine.newBrowser) {
            return Response.error('Engine.newBrowser khong kha dung');
        }
        browser = Engine.newBrowser();
        if (!launchBrowser(browser, url)) {
            return Response.error('Khong the khoi chay trinh duyet');
        }
        let doc = waitForSelector(browser, '.title-detail__row, a[href*="/chapter/"], .title-detail', 25);
        if (!doc) return Response.error('Khong the tai danh sach chapter MangaFire.');

        let script = "(function() {" +
            "window.__mf_toc = { done: false, chapters: [] };" +
            "var seen = {};" +
            "function collect() {" +
                "var rows = document.querySelectorAll('.title-detail__row');" +
                "for (var i = 0; i < rows.length; i++) {" +
                    "var r = rows[i];" +
                    "var a = r.querySelector('a.title-detail__row-link, a[href*=\"/chapter/\"]');" +
                    "if (a) {" +
                        "var href = a.href;" +
                        "if (!seen[href]) {" +
                            "seen[href] = true;" +
                            "var num = r.querySelector('.title-detail__row-num');" +
                            "var numTxt = num ? num.textContent.trim() : '';" +
                            "var sub = r.querySelector('.title-detail__row-sub');" +
                            "var subTxt = sub ? sub.textContent.trim() : '';" +
                            "var name = numTxt ? (numTxt + (subTxt ? ': ' + subTxt : '')) : (subTxt || a.textContent.trim());" +
                            "window.__mf_toc.chapters.push({ name: name, url: href });" +
                        "}" +
                    "}" +
                "}" +
            "}" +
            "collect();" +
            "var maxPages = 50;" +
            "var pageCount = 0;" +
            "var timer = setInterval(function() {" +
                "var nextBtn = document.querySelector('.npager button[aria-label=\"Next page\"]:not([disabled])');" +
                "if (nextBtn && pageCount < maxPages) {" +
                    "pageCount++;" +
                    "nextBtn.click();" +
                    "setTimeout(collect, 150);" +
                "} else {" +
                    "clearInterval(timer);" +
                    "collect();" +
                    "window.__mf_toc.done = true;" +
                "}" +
            "}, 200);" +
            "return 'started';" +
        "})()";

        browser.callJs(script, 3000);
        let chapters = [];
        for (let i = 0; i < 50; i++) {
            sleep(300);
            let statusStr = browser.callJs("(function(){ return window.__mf_toc ? JSON.stringify({ done: window.__mf_toc.done, count: window.__mf_toc.chapters.length }) : ''; })()", 2000);
            if (statusStr) {
                try {
                    let parsed = JSON.parse(statusStr);
                    if (parsed && parsed.done) {
                        let raw = browser.callJs("JSON.stringify(window.__mf_toc.chapters)", 5000);
                        if (raw) {
                            let list = JSON.parse(raw);
                            if (list && list.length > 0) {
                                chapters = list;
                                break;
                            }
                        }
                    }
                } catch (err) {}
            }
        }

        if (chapters.length === 0) {
            let directDoc = browser.html();
            let rows = directDoc ? directDoc.select('.title-detail__row') : null;
            if (rows && rows.size() > 0) {
                for (let i = 0; i < rows.size(); i++) {
                    let r = rows.get(i);
                    let a = r.select('a.title-detail__row-link, a[href*="/chapter/"]').first();
                    if (a) {
                        let num = cleanText(r.select('.title-detail__row-num').text());
                        let sub = cleanText(r.select('.title-detail__row-sub').text());
                        let name = num ? (num + (sub ? ': ' + sub : '')) : (sub || cleanText(a.text()));
                        chapters.push({ name: name, url: normalizeUrl(a.attr('href')) });
                    }
                }
            }
        }

        if (chapters.length === 0) return Response.error('Khong tim thay chapter.');

        chapters.reverse();
        let data = [];
        for (let i = 0; i < chapters.length; i++) {
            let item = chapters[i];
            data.push({
                name: item.name,
                url: normalizeUrl(item.url),
                host: BASE_URL
            });
        }
        return Response.success(data);
    } catch (e) {
        return Response.error('Loi: ' + e);
    } finally {
        if (browser) {
            try { browser.close(); } catch (e) {}
        }
    }
}
