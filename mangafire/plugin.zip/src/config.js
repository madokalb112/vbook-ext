let BASE_URL = "https://mangafire.to";
try {
    if (CONFIG_URL) BASE_URL = CONFIG_URL.replace(/\/+$/, "");
} catch (error) {
}

let BROWSE_URL = BASE_URL + "/browse";
let DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36";
let MOBILE_UA = "Mozilla/5.0 (Linux; Android 12; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Mobile Safari/537.36";

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}

function decodeHtml(text) {
    if (!text) return "";
    return ("" + text)
        .replace(/&amp;/g, "&")
        .replace(/&quot;/g, "\"")
        .replace(/&#039;/g, "'")
        .replace(/&apos;/g, "'")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">");
}

function normalizeUrl(url) {
    if (!url) return "";
    url = decodeHtml(url).trim();
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("/") === 0) return BASE_URL + url;
    if (!/^https?:\/\//i.test(url)) return BASE_URL + "/" + url.replace(/^\/+/, "");
    return url.replace(/^https?:\/\/(?:www\.)?mangafire\.to/i, BASE_URL);
}

function normalizeImage(url) {
    if (!url) return "";
    url = decodeHtml(url).trim();
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("/") === 0) return BASE_URL + url;
    return url;
}

function imageAttr(e) {
    if (!e) return "";
    let currentSrc = e.attr("currentSrc");
    if (currentSrc) return currentSrc;
    let srcset = e.attr("data-srcset") || e.attr("srcset");
    if (srcset) return cleanText(srcset.split(",")[0].split(" ")[0]);
    return e.attr("data-src") || e.attr("data-original") || e.attr("data-lazy-src") || e.attr("data-cfsrc") || e.attr("src") || "";
}

function imageFromNode(e) {
    return normalizeImage(imageAttr(e));
}

function metaContent(doc, selector) {
    let node = doc.select(selector).first();
    return node ? cleanText(node.attr("content")) : "";
}

function metaImage(doc) {
    return normalizeImage(metaContent(doc, "meta[property=og:image], meta[property='og:image:secure_url'], meta[name=twitter:image], meta[itemprop=image]"));
}

function firstText(node, selectors) {
    for (let i = 0; i < selectors.length; i++) {
        let e = node.select(selectors[i]).first();
        let text = e ? cleanText(e.text()) : "";
        if (text) return text;
    }
    return "";
}

function firstHtml(node, selectors) {
    for (let i = 0; i < selectors.length; i++) {
        let e = node.select(selectors[i]).first();
        if (e && cleanText(e.text())) return e.html();
    }
    return "";
}

function pageNum(page) {
    let n = parseInt(page || "1", 10);
    return n > 0 ? n : 1;
}

function addPageParam(url, page) {
    url = normalizeUrl(url || BROWSE_URL);
    let p = pageNum(page);
    if (p <= 1) return url;
    if (url.indexOf("page=") >= 0) return url.replace(/([?&]page=)\d+/i, "$1" + p);
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + "page=" + p;
}

function isStoryUrl(url) {
    if (!url) return false;
    let u = normalizeUrl(url);
    return u.indexOf("/title/") >= 0 && u.indexOf("/chapter/") < 0;
}

function isChapterUrl(url) {
    if (!url) return false;
    let u = normalizeUrl(url);
    return u.indexOf("/chapter/") >= 0 || u.indexOf("/read/") >= 0;
}

function launchBrowser(browser, url) {
    try {
        if (browser && typeof browser.setUserAgent === "function") {
            browser.setUserAgent(DESKTOP_UA);
        }
        if (browser && typeof browser.launchAsync === "function") {
            browser.launchAsync(url);
            return true;
        }
        if (browser && typeof browser.launch === "function") {
            browser.launch(url, 15000);
            return true;
        }
    } catch (error) {
    }
    return false;
}

function waitForSelector(browser, selector, maxAttempts) {
    maxAttempts = maxAttempts || 25;
    let doc = null;
    for (let i = 0; i < maxAttempts; i++) {
        try {
            doc = browser.html();
            if (doc && selector) {
                let node = doc.select(selector);
                if (node && node.size() > 0) return doc;
            } else if (doc) {
                return doc;
            }
        } catch (error) {
        }
        sleep(500);
    }
    return doc;
}

function extractCards(doc) {
    let data = [];
    if (!doc) return data;
    let nodes = doc.select("a.title-rows__link, a[href^='/title/'], a[href*='/title/'], .browse__results a");
    let seen = {};
    for (let i = 0; i < nodes.size(); i++) {
        let a = nodes.get(i);
        let href = normalizeUrl(a.attr("href"));
        if (!href || href.indexOf("/title/") < 0 || href.indexOf("/chapter/") >= 0 || seen[href]) continue;
        seen[href] = true;
        let titleEl = a.select(".title-row-card__title, [class*=title]").first();
        let title = cleanText(titleEl ? titleEl.text() : a.text());
        if (!title || title.length < 2) continue;
        let imgNode = a.select("img").first();
        let cover = imgNode ? imageFromNode(imgNode) : "";
        let type = cleanText(a.select(".title-row-card__type").text());
        let ch = cleanText(a.select(".title-row-card__ch").text());
        let desc = type && ch ? (type + " - " + ch) : (type || ch || "");
        data.push({
            name: title,
            link: href,
            cover: cover,
            description: desc,
            host: BASE_URL
        });
    }
    return data;
}

function imageHeaders(referer) {
    return {
        "Referer": BASE_URL + "/",
        "User-Agent": DESKTOP_UA
    };
}
