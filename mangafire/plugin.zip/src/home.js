load('config.js');

function execute() {
    return Response.success([
        {title: "Trending Manga", input: BASE_URL + "/browse?types=manga&sort=views_7d:desc", script: "gen.js"},
        {title: "Trending Webtoon", input: BASE_URL + "/browse?types=manhwa,manhua&sort=views_7d:desc", script: "gen.js"},
        {title: "Recently Updated", input: BASE_URL + "/browse?sort=chapter_updated_at:desc", script: "gen.js"},
        {title: "Recently Added", input: BASE_URL + "/browse?sort=created_at:desc", script: "gen.js"},
        {title: "Manga", input: BASE_URL + "/browse?types=manga", script: "gen.js"},
        {title: "Manhwa", input: BASE_URL + "/browse?types=manhwa", script: "gen.js"},
        {title: "Manhua", input: BASE_URL + "/browse?types=manhua", script: "gen.js"},
        {title: "Browse All", input: BASE_URL + "/browse", script: "gen.js"}
    ]);
}
