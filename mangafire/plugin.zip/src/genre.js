load('config.js');

function execute() {
    return Response.success([
        {title: "All", input: BASE_URL + "/browse", script: "gen.js"},
        {title: "Manga", input: BASE_URL + "/browse?types=manga", script: "gen.js"},
        {title: "Manhwa", input: BASE_URL + "/browse?types=manhwa", script: "gen.js"},
        {title: "Manhua", input: BASE_URL + "/browse?types=manhua", script: "gen.js"},
        {title: "Trending", input: BASE_URL + "/browse?sort=views_7d:desc", script: "gen.js"},
        {title: "Recently Updated", input: BASE_URL + "/browse?sort=chapter_updated_at:desc", script: "gen.js"},
        {title: "Recently Added", input: BASE_URL + "/browse?sort=created_at:desc", script: "gen.js"},
        {title: "Highest Rated", input: BASE_URL + "/browse?sort=highest_rated:desc", script: "gen.js"},
        {title: "Most Followed", input: BASE_URL + "/browse?sort=most_followed:desc", script: "gen.js"},
        {title: "Most Viewed (7 days)", input: BASE_URL + "/browse?sort=views_7d:desc", script: "gen.js"},
        {title: "Most Viewed (30 days)", input: BASE_URL + "/browse?sort=views_30d:desc", script: "gen.js"},
        {title: "Shounen", input: BASE_URL + "/browse?demographics=268918", script: "gen.js"},
        {title: "Shoujo", input: BASE_URL + "/browse?demographics=268919", script: "gen.js"},
        {title: "Seinen", input: BASE_URL + "/browse?demographics=268920", script: "gen.js"},
        {title: "Josei", input: BASE_URL + "/browse?demographics=268921", script: "gen.js"},
        {title: "Comedy", input: BASE_URL + "/browse?genres_in=5", script: "gen.js"},
        {title: "Adventure", input: BASE_URL + "/browse?genres_in=78", script: "gen.js"},
        {title: "Fantasy", input: BASE_URL + "/browse?genres_in=79", script: "gen.js"},
        {title: "School Life", input: BASE_URL + "/browse?theme_ids=268959", script: "gen.js"},
        {title: "Supernatural", input: BASE_URL + "/browse?theme_ids=268961", script: "gen.js"}
    ]);
}
