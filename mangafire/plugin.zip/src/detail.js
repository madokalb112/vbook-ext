load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let browser = null;
    try {
        if (typeof Engine === 'undefined' || !Engine || !Engine.newBrowser) {
            return Response.error('Engine.newBrowser khong kha dung');
        }
        browser = Engine.newBrowser();
        if (!launchBrowser(browser, url)) {
            return Response.error('Khong the khoi chay trinh duyet');
        }
        let doc = waitForSelector(browser, '.title-detail, h1', 25);
        if (!doc) return Response.error('Khong the tai thong tin truyen MangaFire.');

        let h1Node = doc.select('h1, .title-detail__title').first();
        let name = cleanText(h1Node ? h1Node.text() : '');
        if (!name) name = metaContent(doc, 'meta[property=og:title]');
        if (!name) return Response.error('Khong tim thay ten truyen.');

        let coverNode = doc.select('.title-detail__poster img, [class*=poster] img').first();
        let cover = coverNode ? imageFromNode(coverNode) : metaImage(doc);

        let authorNode = doc.select('a[href*="authors="], a[href*="artists="]');
        let author = authorNode.size() > 0 ? cleanText(authorNode.first().text()) : '';

        let statusNode = doc.select('.title-detail__badges .badge--status');
        let status = statusNode.size() > 0 ? cleanText(statusNode.text()) : '';

        let typeNode = doc.select('.title-detail__badges .badge');
        let type = typeNode.size() > 0 ? cleanText(typeNode.first().text()) : '';

        let descNode = doc.select('.title-detail__synopsis, [class*=synopsis], [class*=description]').first();
        let description = descNode ? cleanText(descNode.html()) : '';

        let genres = [];
        let seenG = {};
        let genreNodes = doc.select('a[href*="genres_in="], a[href*="theme_ids="], a[href*="demographics="]');
        for (let i = 0; i < genreNodes.size(); i++) {
            let g = genreNodes.get(i);
            let gTitle = cleanText(g.text());
            let gHref = normalizeUrl(g.attr('href'));
            if (gTitle && gHref && !seenG[gHref]) {
                seenG[gHref] = true;
                genres.push({
                    title: gTitle,
                    input: gHref,
                    script: 'gen.js'
                });
            }
        }

        let details = [];
        if (author) details.push('<b>Author:</b> ' + author);
        if (status) details.push('<b>Status:</b> ' + status);
        if (type) details.push('<b>Type:</b> ' + type);

        return Response.success({
            name: name,
            cover: cover,
            author: author || 'Unknown',
            description: description,
            detail: details.join('<br>'),
            ongoing: status.toLowerCase().indexOf('completed') < 0,
            genres: genres,
            host: BASE_URL
        });
    } catch (e) {
        return Response.error('Loi: ' + e);
    } finally {
        if (browser) {
            try { browser.close(); } catch (e) {}
        }
    }
}
