load('config.js');

function execute(url, page) {
    let target = addPageParam(url || BROWSE_URL, page);
    let browser = null;
    try {
        if (typeof Engine === 'undefined' || !Engine || !Engine.newBrowser) {
            return Response.error('Engine.newBrowser khong kha dung');
        }
        browser = Engine.newBrowser();
        if (!launchBrowser(browser, target)) {
            return Response.error('Khong the khoi chay trinh duyet');
        }
        let doc = waitForSelector(browser, 'a[href*="/title/"], .browse__results, .title-row-card', 25);
        if (!doc) return Response.error('Khong the tai danh sach truyen MangaFire.');

        let data = extractCards(doc);
        let next = '';
        if (data.length >= 30 || doc.select('.npager button[aria-label="Next page"]:not([disabled])').size() > 0) {
            next = '' + (pageNum(page) + 1);
        }
        return Response.success(data, next);
    } catch (e) {
        return Response.error('Loi: ' + e);
    } finally {
        if (browser) {
            try { browser.close(); } catch (e) {}
        }
    }
}
