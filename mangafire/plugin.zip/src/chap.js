load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let browser = null;
    try {
        if (typeof Engine === 'undefined' || !Engine || !Engine.newBrowser) {
            return Response.error('Engine.newBrowser khong kha dung');
        }
        browser = Engine.newBrowser();
        if (!launchBrowser(browser, url)) {
            return Response.error('Khong the khoi chay trinh duyet');
        }
        let doc = waitForSelector(browser, '.swiper, .reader__page, [class*=reader] img', 25);
        if (!doc) return Response.error('Khong the tai anh chapter MangaFire.');

        let script = "(function() {" +
            "window.__mf_chap = { done: false, map: {} };" +
            "var swiper = document.querySelector('.swiper') ? document.querySelector('.swiper').swiper : null;" +
            "if (!swiper || !swiper.slides || swiper.slides.length === 0) {" +
                "var imgs = document.querySelectorAll('img.reader-img, img[alt^=\"page\"], [class*=reader] img');" +
                "for (var i = 0; i < imgs.length; i++) {" +
                    "var src = imgs[i].currentSrc || imgs[i].src;" +
                    "if (src) window.__mf_chap.map[i + 1] = src;" +
                "}" +
                "window.__mf_chap.done = true;" +
                "return 'no-swiper';" +
            "}" +
            "var idx = 0;" +
            "var total = swiper.slides.length;" +
            "function scan() {" +
                "var imgs = document.querySelectorAll('img.reader-img, img[alt^=\"page\"]');" +
                "for (var i = 0; i < imgs.length; i++) {" +
                    "var img = imgs[i];" +
                    "var alt = img.getAttribute('alt') || '';" +
                    "var match = /page\\s*(\\d+)/i.exec(alt);" +
                    "var num = match ? parseInt(match[1]) : null;" +
                    "var src = img.currentSrc || img.src;" +
                    "if (src && num) window.__mf_chap.map[num] = src;" +
                "}" +
            "}" +
            "scan();" +
            "var timer = setInterval(function() {" +
                "if (idx < total) {" +
                    "swiper.slideTo(idx, 0);" +
                    "scan();" +
                    "idx++;" +
                "} else {" +
                    "clearInterval(timer);" +
                    "scan();" +
                    "window.__mf_chap.done = true;" +
                "}" +
            "}, 100);" +
            "return 'started';" +
        "})()";

        browser.callJs(script, 3000);
        let map = null;
        for (let i = 0; i < 40; i++) {
            sleep(300);
            let statusStr = browser.callJs("(function(){ return window.__mf_chap ? JSON.stringify({ done: window.__mf_chap.done, count: Object.keys(window.__mf_chap.map).length }) : ''; })()", 2000);
            if (statusStr) {
                try {
                    let parsed = JSON.parse(statusStr);
                    if (parsed && parsed.done && parsed.count > 0) {
                        let raw = browser.callJs("JSON.stringify(window.__mf_chap.map)", 5000);
                        if (raw) {
                            map = JSON.parse(raw);
                            break;
                        }
                    }
                } catch (err) {}
            }
        }

        let headers = imageHeaders(url);
        let data = [];
        if (map && Object.keys(map).length > 0) {
            let pageNums = Object.keys(map).map(function(k) { return parseInt(k); }).sort(function(a, b) { return a - b; });
            for (let i = 0; i < pageNums.length; i++) {
                let link = map['' + pageNums[i]];
                if (link) {
                    data.push({
                        link: normalizeImage(link),
                        headers: headers,
                        header: headers
                    });
                }
            }
        }

        if (data.length === 0) {
            let directDoc = browser.html();
            let imgs = directDoc ? directDoc.select('img.reader-img, .swiper-slide img, [class*=reader] img') : null;
            if (imgs && imgs.size() > 0) {
                let seen = {};
                for (let i = 0; i < imgs.size(); i++) {
                    let link = imageFromNode(imgs.get(i));
                    if (link && !seen[link] && link.indexOf('logo') < 0 && link.indexOf('banner') < 0) {
                        seen[link] = true;
                        data.push({
                            link: link,
                            headers: headers,
                            header: headers
                        });
                    }
                }
            }
        }

        if (data.length === 0) return Response.error('Khong lay duoc anh chapter MangaFire.');
        return Response.success(data);
    } catch (e) {
        return Response.error('Loi: ' + e);
    } finally {
        if (browser) {
            try { browser.close(); } catch (e) {}
        }
    }
}
