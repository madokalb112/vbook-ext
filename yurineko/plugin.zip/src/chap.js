load('config.js');

function cleanEscapedUrl(url) {
    return (url || '')
        .replace(/\\u0026/g, '&')
        .replace(/\u0026/g, '&')
        .replace(/&amp;/g, '&')
        .replace(/\\\//g, '/')
        .replace(/\\+$/, '');
}

function extractImageKey(html) {
    html = (html || '').replace(/&quot;/g, '"');
    var direct = /imgKey\\?":\\?"([^"\\]+)/.exec(html) || /['"]imgKey['"]\s*:\s*['"]([^'"]+)/.exec(html);
    return direct ? direct[1] : '';
}

function extractImageUrls(html) {
    var q = String.fromCharCode(34);
    var apos = String.fromCharCode(39);
    var re = new RegExp('/api/img\\?d=[^' + q + apos + '<>\\s]+', 'g');
    var data = [];
    var seen = {};
    var match;
    while ((match = re.exec(html || '')) !== null) {
        var url = cleanEscapedUrl(match[0]);
        if (!url || seen[url]) continue;
        seen[url] = true;
        data.push(normalizeUrl(url));
    }
    return data;
}

function fetchPageHtml(url) {
    var page = '';
    try {
        var response = request(url, {headers: {'Accept': 'text/html,*/*'}}, url);
        if (response && response.ok) page = response.text();
    } catch (error) {
    }
    if (page && page.indexOf('imgKey') >= 0) return page;

    try {
        var doc = browserDoc(url, '/api/img?d=', 4500);
        if (doc && doc.html) {
            var html = doc.html();
            if (html && html.indexOf('imgKey') >= 0) return html;
            if (!page) page = html || '';
        }
    } catch (browserError) {
    }
    return page;
}

function proxyBaseUrl() {
    try {
        return stripTrailingSlash(IMAGE_PROXY_URL || '');
    } catch (error) {
        return '';
    }
}

function hashString(text) {
    var hash = 5381;
    text = '' + (text || '');
    for (var i = 0; i < text.length; i++) hash = ((hash << 5) + hash + text.charCodeAt(i)) | 0;
    hash = hash >>> 0;
    return ('00000000' + hash.toString(16)).slice(-8);
}

function proxyChapterId(referer, key, urls) {
    return 'yn_' + hashString(referer + '\n' + key + '\n' + urls.join('\n'));
}

function addParam(url, key, value) {
    if (value === undefined || value === null) value = '';
    return url + (url.indexOf('?') >= 0 ? '&' : '?') + key + '=' + encodeURIComponent(value);
}

function proxyImageUrl(cid, index) {
    var url = proxyBaseUrl() + '/img';
    url = addParam(url, 'cid', cid);
    url = addParam(url, 'i', index);
    return url;
}

function proxyFallbackImageUrl(sourceUrl, key, referer) {
    var url = proxyBaseUrl() + '/img';
    url = addParam(url, 'u', sourceUrl);
    url = addParam(url, 'ik', key);
    url = addParam(url, 'ref', referer);
    return url;
}

function registerProxyChapter(cid, urls, key, referer) {
    var proxy = proxyBaseUrl();
    if (!proxy) return false;

    try {
        var response = fetch(proxy + '/chapter?wait=first', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({cid: cid, urls: urls, ik: key, ref: referer, wait: 'first'})
        });
        return !!(response && response.ok);
    } catch (error) {
        return false;
    }
}

function proxyPrefetchEnabled() {
    try {
        return IMAGE_PROXY_PREFETCH === true;
    } catch (error) {
        return false;
    }
}

function execute(url) {
    url = normalizeUrl(url);
    var proxy = proxyBaseUrl();
    if (!proxy) return Response.error('Chua cau hinh IMAGE_PROXY_URL.');

    var page = fetchPageHtml(url);
    var key = extractImageKey(page);
    var urls = extractImageUrls(page);
    if (!key || urls.length === 0) return Response.error('Khong tim thay du lieu anh chapter. Hay thu bam Trang nguon de vuot Cloudflare roi tai lai.');

    var cid = proxyChapterId(url, key, urls);
    var registered = proxyPrefetchEnabled() ? registerProxyChapter(cid, urls, key, url) : false;

    var data = [];
    for (var i = 0; i < urls.length; i++) {
        data.push({link: registered ? proxyImageUrl(cid, i) : proxyFallbackImageUrl(urls[i], key, url)});
    }
    return Response.success(data);
}
