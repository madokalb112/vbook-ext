load('config.js');

var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function cleanEscapedUrl(url) {
    return (url || '')
        .replace(/\\u0026/g, '&')
        .replace(/\u0026/g, '&')
        .replace(/&amp;/g, '&')
        .replace(/\\\//g, '/')
        .replace(/\\+$/, '');
}

function extractImageKey(html) {
    html = (html || '').replace(/&quot;/g, '"');
    var direct = /imgKey\\?":\\?"([^"\\]+)/.exec(html) || /['"]imgKey['"]\s*:\s*['"]([^'"]+)/.exec(html);
    return direct ? direct[1] : '';
}

function extractImageUrls(html) {
    var q = String.fromCharCode(34);
    var apos = String.fromCharCode(39);
    var re = new RegExp('/api/img\\?d=[^' + q + apos + '<>\\s]+', 'g');
    var data = [];
    var seen = {};
    var match;
    while ((match = re.exec(html || '')) !== null) {
        var url = cleanEscapedUrl(match[0]);
        if (!url || seen[url]) continue;
        seen[url] = true;
        data.push(url);
    }
    return data;
}

function b64Decode(input) {
    input = (input || '').replace(/[^A-Za-z0-9\+\/\=]/g, '');
    var out = [];
    for (var i = 0; i < input.length; i += 4) {
        var c1 = B64.indexOf(input.charAt(i));
        var c2 = B64.indexOf(input.charAt(i + 1));
        var c3 = B64.indexOf(input.charAt(i + 2));
        var c4 = B64.indexOf(input.charAt(i + 3));
        out.push(((c1 << 2) | (c2 >> 4)) & 255);
        if (input.charAt(i + 2) !== '=') out.push(((c2 & 15) << 4) | (c3 >> 2));
        if (input.charAt(i + 3) !== '=') out.push(((c3 & 3) << 6) | c4);
    }
    return out;
}

function b64Encode(bytes) {
    var out = '';
    for (var i = 0; i < bytes.length; i += 3) {
        var b1 = bytes[i] & 255;
        var b2 = i + 1 < bytes.length ? bytes[i + 1] & 255 : 0;
        var b3 = i + 2 < bytes.length ? bytes[i + 2] & 255 : 0;
        out += B64.charAt(b1 >> 2);
        out += B64.charAt(((b1 & 3) << 4) | (b2 >> 4));
        out += i + 1 < bytes.length ? B64.charAt(((b2 & 15) << 2) | (b3 >> 6)) : '=';
        out += i + 2 < bytes.length ? B64.charAt(b3 & 63) : '=';
    }
    return out;
}

function xorBytes(bytes, key) {
    if (!key) return bytes;
    var kb = [];
    for (var i = 0; i < key.length; i += 2) kb.push(parseInt(key.substring(i, i + 2), 16));
    for (var j = 0; j < bytes.length; j++) bytes[j] = bytes[j] ^ kb[j % kb.length];
    return bytes;
}

function imageBase64(apiUrl, key, referer) {
    try {
        var headers = {
            'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
            'Referer': referer
        };
        if (key) headers['X-Ik'] = key;
        var response = request(apiUrl, {headers: headers}, referer);
        if (!response || !response.ok || typeof response.base64 !== 'function') return '';
        var raw = response.base64();
        if (!raw) return '';
        return b64Encode(xorBytes(b64Decode(raw), key));
    } catch (error) {
        return '';
    }
}

function execute(url) {
    url = normalizeUrl(url);
    var page = '';
    try {
        var response = request(url, {headers: {'Accept': 'text/html,*/*'}}, url);
        if (response && response.ok) page = response.text();
    } catch (error) {
    }

    var key = extractImageKey(page);
    var urls = extractImageUrls(page);
    if (!key || urls.length === 0) return Response.error('Khong tim thay du lieu anh chapter. Hay thu bam Trang nguon de vuot Cloudflare roi tai lai.');

    var data = [];
    for (var i = 0; i < urls.length; i++) {
        var img = imageBase64(urls[i], key, url);
        if (img) data.push({link: 'data:image/webp;base64,' + img});
    }

    if (data.length === 0) return Response.error('Khong tai duoc anh chapter.');
    return Response.success(data);
}
