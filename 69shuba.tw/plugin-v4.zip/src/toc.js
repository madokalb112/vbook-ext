load("config.js");

function parseChapters(doc, bookId, seen) {
    let data = [];
    let items = doc.select("a[href*='/read/" + bookId + "/'], .protected-chapter-link[data-cid-url]");
    for (let i = 0; i < items.size(); i++) {
        let node = items.get(i);
        let link = normalizeUrl(node.attr("href") || node.attr("data-cid-url"));
        if (!isChapterUrl(link) || seen[link]) continue;

        let name = cleanText(node.text() || node.attr("title") || node.attr("data-title"));
        if (!name || name === "上一页" || name === "下一页" || name === "返回目录" || name === "返回目錄") continue;

        seen[link] = true;
        data.push({
            name: name,
            url: link,
            host: BASE_URL
        });
    }
    return data;
}

function collectTocPages(doc, bookId) {
    let data = [];
    let seen = {};
    let pattern = "/indexlist/" + bookId + "/";
    let items = doc.select("a[href], option[value]");

    for (let i = 0; i < items.size(); i++) {
        let node = items.get(i);
        let link = normalizeUrl(node.attr("href") || node.attr("value"));
        if (!link || seen[link]) continue;
        if (!isTocUrl(link) || storyIdFromUrl(link) !== bookId) continue;
        if (link.indexOf(pattern) < 0) continue;
        seen[link] = true;
        data.push(link);
    }

    data.sort(function(a, b) {
        return pageNumberFromUrl(a) - pageNumberFromUrl(b);
    });
    return data;
}

function execute(url) {
    let bookId = storyIdFromUrl(url);
    if (!bookId) return Response.error("Url truyen khong hop le.");

    let firstUrl = tocUrl(bookId, 1);
    let session = openBrowserSession(firstUrl);
    if (!session) return loadError();

    let data = [];
    let seenChapters = {};
    let seenPages = {};
    let queuedPages = {};
    let queue = [firstUrl];
    let firstDoc = session.doc && !isChallengeDoc(session.doc) ? session.doc : browserFetchDoc(session, firstUrl);

    queuedPages[normalizeUrl(firstUrl)] = true;

    try {
        for (let i = 0; i < 200 && queue.length > 0; i++) {
            let target = normalizeUrl(queue.shift());
            if (!target || seenPages[target]) continue;

            let doc = target === normalizeUrl(firstUrl) ? firstDoc : browserFetchDoc(session, target);
            seenPages[target] = true;
            if (!doc) {
                if (target === normalizeUrl(firstUrl)) return loadError();
                continue;
            }

            let rows = parseChapters(doc, bookId, seenChapters);
            for (let j = 0; j < rows.length; j++) data.push(rows[j]);

            let pages = collectTocPages(doc, bookId);
            for (let j = 0; j < pages.length; j++) {
                let pageUrl = normalizeUrl(pages[j]);
                if (!pageUrl || seenPages[pageUrl] || queuedPages[pageUrl]) continue;
                queuedPages[pageUrl] = true;
                queue.push(pageUrl);
            }
        }

        if (Object.keys(seenPages).length <= 1) {
            for (let page = 2; page <= 200; page++) {
                let pageUrl = tocUrl(bookId, page);
                if (seenPages[pageUrl]) continue;

                let doc = browserFetchDoc(session, pageUrl);
                if (!doc) break;

                let rows = parseChapters(doc, bookId, seenChapters);
                if (rows.length === 0) break;

                seenPages[pageUrl] = true;
                for (let j = 0; j < rows.length; j++) data.push(rows[j]);
            }
        }
    } finally {
        closeBrowserSession(session);
    }

    if (data.length === 0) return loadError("Khong tim thay danh sach chuong.");
    if (data.length > 1 && chapterNumber(data[0].name) > chapterNumber(data[data.length - 1].name)) data.reverse();
    return Response.success(data);
}
